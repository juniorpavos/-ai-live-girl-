# AI LIVE GIRL — base Android

Proyecto Android nativo en Kotlin. Incluye una vista previa de la cámara frontal con CameraX.

## Requisitos
- Android Studio / Gradle
- JDK 17
- Android SDK Platform 35

## Compilar
Desde la carpeta del proyecto:

```bash
gradle :app:assembleDebug
```

La APK debug se genera en:

`app/build/outputs/apk/debug/app-debug.apk`

## Importante
Esta versión es solamente una base de cámara. No implementa todavía avatar facial, conversión de voz, grabación de videos ni conexión con TikTok LIVE. Ver `CLAUDE_INSTRUCTIONS.txt` para el pedido de desarrollo por etapas.
